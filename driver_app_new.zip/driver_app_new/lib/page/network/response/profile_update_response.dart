class ProfileUpdateResponse {
  String success;
  String message;

  ProfileUpdateResponse({this.success, this.message});

  ProfileUpdateResponse.fromJson(Map<String, dynamic> json) {
    success = json['success'].toString();
    message = json['message'].toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['success'] = this.success;
    data['message'] = this.message;
    return data;
  }
}
