// import 'package:driver_app/helper/user.dart';
//
//
// class UpdateProfileResponse {
//   UserData driver;
//   int success;
//   String message;
//
//   UpdateProfileResponse.fromJson(Map<String, dynamic> json) {
//     message = json['message'];
//     success = json['success'];
//     driver = UserData.fromJson(json['driver']);
//   }
// }
